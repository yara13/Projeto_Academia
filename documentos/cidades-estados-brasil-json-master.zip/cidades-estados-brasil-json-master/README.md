Cidades Estados do Brasil em JSON
====================

Array de estados (com acentos) e cidades(com acentos) do Brasil em JSON com ID relacionado.